// api.js

function sendLoginRequest(email, password) {
    return new Promise((resolve, reject) => {
      const xhr = new XMLHttpRequest();
      xhr.open('POST', 'http://localhost:4000/studenti', true);
      xhr.setRequestHeader('Content-Type', 'application/json');
  
      xhr.onreadystatechange = function () {
        if (xhr.readyState === 4) {
          if (xhr.status === 200) {
            const response = JSON.parse(xhr.responseText);
            resolve(response);
          } else {
            reject(new Error('Greška u komunikaciji sa serverom. Status: ' + xhr.status));
          }
        }
      };
  
      xhr.send(JSON.stringify({ korisnicko_ime: email, lozinka: password }));
    });
  }
  
  module.exports = { sendLoginRequest };
  