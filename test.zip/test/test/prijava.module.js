const { login } = require('./loginModule');
const { sendLoginRequest } = require('./api');

async function prijava(email, password) {
  try {
    const response = await sendLoginRequest(email, password);

    if (response.success) {
      console.log('Uspješna prijava:', response.student);
      window.localStorage.setItem('email', email);
      window.location.href = 'ocjene.html';
      return true;
    } else {
      console.error('Pogrešno korisničko ime ili lozinka:', response.message);
      document.getElementById('email').value = '';
      document.getElementById('password').value = '';
      alert('Pogrešno korisničko ime ili lozinka.');
      return false;
    }
  } catch (error) {
    console.error(error.message);
    alert('Greška u komunikaciji sa serverom.');
    return false;
  }
}

module.exports = { prijava };
