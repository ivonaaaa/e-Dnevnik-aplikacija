// loginModule.js

// Simulacija baze podataka
const usersDatabase = [
    {
      ime: 'John',
      prezime: 'Doe',
      razred: '12',
      korisnicko_ime: 'john_doe',
      lozinka: 'password123',
      skola: {
        naziv: 'Škola XYZ',
        mjesto: 'Grad A'
      },
      ime_prezime_razrednika: 'Profesor Smith'
    },
    // Dodajte dodatne korisničke račune prema potrebi
  ];
  
  function login(username, password) {
    // Pronađi korisnika u simuliranoj bazi podataka
    const user = usersDatabase.find(u => u.korisnicko_ime === username);
  
    if (user && user.lozinka === password) {
      // Prijava uspješna
      return true;
    } else {
      // Prijava neuspješna
      return false;
    }
  }
  
  module.exports = { login };
  // loginModule.js

