// login.test.js
const { login } = require('./loginModule');
const { sendLoginRequest } = require('./api');

class MockXMLHttpRequest {
  open() {}
  setRequestHeader() {}
  send() {
    this.onreadystatechange();
  }
}

describe('Login functionality', () => {
  test('Successful login should return true', () => {
    const result = login('john_doe', 'password123');
    expect(result).toBe(true);
  });

  test('Unsuccessful login should return false', () => {
    const result = login('invalid_user', 'invalid_password');
    expect(result).toBe(false);
  });

  describe('HTTP communication', () => {
    test('Sending login request should resolve with success', async () => {
      global.XMLHttpRequest = jest.fn(() => new MockXMLHttpRequest());
      const responsePromise = sendLoginRequest('john_doe', 'password123');
      
      // Sačekaj da se asinkroni dio završi
      await responsePromise;

      // Očekuj da će se promise razriješiti s uspjehom
      expect(responsePromise).resolves.toEqual({
        success: true,
        student: {},
      });
    });

    test('Sending login request should reject with an error on failure', async () => {
      global.XMLHttpRequest = jest.fn(() => new MockXMLHttpRequest());
      const responsePromise = sendLoginRequest('john_doe', 'password123');

      // Sačekaj da se asinkroni dio završi
      await responsePromise;

      // Očekuj da će se promise odbiti s greškom
      await expect(responsePromise).rejects.toThrowError(
        'Greška u komunikaciji sa serverom. Status: 500'
      );
    });
  });
});
